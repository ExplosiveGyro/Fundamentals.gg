import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, Youtube, Twitch, Twitter } from 'lucide-react';

export default function GyroCoachingWebsite() {
  const [email, setEmail] = useState('');

  return (
    <div className="p-6 space-y-12 max-w-5xl mx-auto">
      {/* Hero Section */}
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Coaching by Gyro</h1>
        <p className="text-xl text-muted-foreground">
          Elite Rocket League coaching by Jirair “Gyro” Papazian
        </p>
        <div className="flex justify-center space-x-4">
          <Button asChild><a href="#coaching">Book Coaching</a></Button>
          <Button variant="outline" asChild><a href="#guides">View Guides</a></Button>
        </div>
      </section>

      {/* About Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">About Gyro</h2>
        <p>
          Veteran of 9 years in Rocket League. 2019 DreamHack Montreal LAN Champion, Top 5 at RLCS Worlds, and one of only a few players to never miss an NA RLCS Main Event.
        </p>
        <p>
          Played for: Pittsburgh Knights, Faze, Rogue, Koi, Dignitas, Deleted Gaming.
        </p>
        <p>
          Coaching since 2024 on Metafy, helping players like Frosty and Reveal reach RLCS.
        </p>
      </section>

      {/* Guides Section */}
      <section id="guides" className="space-y-4">
        <h2 className="text-2xl font-semibold">Guides & Tips</h2>
        <Card>
          <CardContent className="p-4 space-y-2">
            <h3 className="text-xl font-medium">Rotation Mastery</h3>
            <p>Understand positioning like a pro. Ideal for Champs-GC players.</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 space-y-2">
            <h3 className="text-xl font-medium">Mental Edge</h3>
            <p>How to stay calm and make smart decisions under pressure.</p>
          </CardContent>
        </Card>
      </section>

      {/* Videos Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Videos</h2>
        <div className="aspect-video">
          <iframe
            width="100%"
            height="315"
            src="https://www.youtube.com/embed?list=UU0_WTfT6gLa4WvG6bE3wbJg"
            title="Gyro's YouTube Videos"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </section>

      {/* Coaching Section */}
      <section id="coaching" className="space-y-4">
        <h2 className="text-2xl font-semibold">Book Coaching</h2>
        <p>1-on-1 and replay reviews available through Metafy.</p>
        <Button asChild>
          <a href="https://metafy.gg/@gyro" target="_blank">Book on Metafy</a>
        </Button>
      </section>

      {/* Contact & Socials */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Stay Connected</h2>
        <div className="flex space-x-4">
          <a href="https://www.youtube.com/@ExplosiveGyro" target="_blank"><Youtube /></a>
          <a href="https://www.twitch.tv/ExplosiveGyro" target="_blank"><Twitch /></a>
          <a href="https://twitter.com/ExplosiveGyro" target="_blank"><Twitter /></a>
          <a href="mailto:gyro@yourdomain.com"><Mail /></a>
        </div>
      </section>
    </div>
  );
}